function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);//changes background color
  fill(225);
  textSize(30);
  m= month();
  d= day();
  y= year();
  h= hour();
  mi=minute();
  se=second();
  text(m+'/'+d+'/'+y,100,250);
  textSize(30);
  text(h+':'+mi+':'+se,100,350);
}

