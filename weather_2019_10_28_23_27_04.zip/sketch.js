
let weather="";
let json;
let img;
function preload(){
  let weather_url="https://api.openweathermap.org/data/2.5/weather?q=Lubbock&units=imperial&APPID=3ef80adea47b29f2cdc09057cb0b1fa6";
json=loadJSON(weather_url);
}

  
function setup() {
  createCanvas(400, 400);
  weather=json.main.temp;
  img = loadImage('1.png'); // Load the image
  
}

function draw() {
  background(255);
  fill(0);
  text(weather+ "\xB0F",10,90);
  image(img, 20, 90);
}